== Opus Audio Tools ==

This is opus-tools, a set of tools to encode, inspect, and decode
audio in the Opus format.

For more information on Opus see http://www.opus-codec.org/

There is basic documentation in the HTML files included in this archive.

-------------------------------------------------------------------------
These Win32 opus-tools binaries were cross-compiled with mingw from: 

opus-tools-0.1.5.tar.gz
corrsponding to http://git.xiph.org/?p=opus-tools.git
commit: 8eb11fd62ffc6840dde71ce4dceb15fe84addcb1
tag: v0.1.5

and http://git.xiph.org/?p=opus.git
commit: 12190653b2008346d3149d9a32d7e1dff42835d7
tag: v1.0.1-rc3

You can verify the files with:
 sha256sum -c SHA256SUMS.txt
 gpg --verify SHA256SUMS.txt.asc

These tools are available as part of cygwin: http://www.cygwin.com/
-------------------------------------------------------------------------

Please send any comments/bug reports on these tools
send email to Ralph Giles <giles@mozilla.com> and
Greg Maxwell <greg@xiph.org>.
